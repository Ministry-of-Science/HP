A Pen created at CodePen.io. You can find this one at https://codepen.io/shubniggurath/pen/NXGbBo.

 Fractal noise distortions. Super heavy, will probably not behave nicely on mobile, sorry for that :)

Clicking will increase the number of fractions in the calculation. WARNNG: Only do this is you have a decent GPU :)

A special thanks, as always, to [Inigo Quilez](https://twitter.com/iquilezles) and [Patricio Gonzalez Vivo](https://twitter.com/patriciogv). Upon the shoulders of giants, I stand.

Move your mouse to increase the speed of the simulation.