A Pen created at CodePen.io. You can find this one at https://codepen.io/willdonohoe/pen/VyLNeZ.

 An interactive and animated album artwork from George FitzGerald. https://images-na.ssl-images-amazon.com/images/I/716l%2BugGwEL._SL1400_.jpg

* Animated linear gradients for each for each of the rectangles
* Radial animation delay depending on where the user clicked
* CSS animations / transitions used for movement
