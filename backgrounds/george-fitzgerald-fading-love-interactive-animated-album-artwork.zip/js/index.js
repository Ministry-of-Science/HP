class App {

  constructor() {
    this.windowSize = {
      width: window.innerWidth,
      height: window.innerHeight
    };

    this.blocks = [];

    this.blockSize = {
      width: 135,
      height: 10
    }

    this.radius = Math.max(this.blockSize.width, this.blockSize.height);

    this.gutter = 10;

    this.autoAnimationInterval_ = 0;

    this.waitForAnimationTimeout_ = 0;

    this.resizeTimeout_ = 0;

    this.logo = document.querySelector('.logo');

    this.lastResetSize = this.windowSize;

    this.container = document.createElement('div');

    this.init();
  }


  init() {
    this.createBlocks();

    const wrapper = document.querySelector('.wrapper');
    wrapper.appendChild(this.container);

    window.addEventListener('click', this.onInteractionStart.bind(this));
    document.body.addEventListener('touchstart', this.onInteractionStart.bind(this));

    window.addEventListener('resize', this.resize.bind(this), false);

    this.waitToStartAutoAnimation();

    setTimeout(() => {
      this.logo.classList.add('animate-in');
    });
  }

  onInteractionStart(evt) {
    console.log('interaction start');
    let target = {
      x: 0,
      y: 0
    };
    switch(evt.type) {
      case 'touchstart':
        target = {
          x: evt.touches[0].clientX,
          y: evt.touches[0].clientY
        }
      break;
      case 'click':
        target = {
          x: evt.clientX,
          y: evt.clientY
        }
      break;
    }

    this.rotateBlocks(target);

    this.waitToStartAutoAnimation();
  }

  waitToStartAutoAnimation() {
    if (this.waitForAnimationTimeout_) {
      clearTimeout(this.waitForAnimationTimeout_);
    }
    if (this.autoAnimationInterval_) {
      clearInterval(this.autoAnimationInterval_);
    }
    this.waitForAnimationTimeout_ = setTimeout(() => this.restartAutoAnimationTimer(), 2000);
  }

  restartAutoAnimationTimer() {
    if (this.autoAnimationInterval_) {
      clearInterval(this.autoAnimationInterval_);
    }

    this.autoAnimationInterval_ = setInterval(() => {
      const randomPosition = {
        x: Math.random() * this.windowSize.width,
        y: Math.random() * this.windowSize.height
      };
      this.rotateBlocks(randomPosition);
    }, 5000);
  }

  getStartingCorner(x, y) {
    return [
      x < windowSize.width / 2 ? 0 : 1,
      y < windowSize.height / 2 ? 0 : 1,
    ];
  }

  rotateBlocks(target) {
    this.blocks.forEach((block) => {
      const distanceRatio = Math.abs((target.x / this.windowSize.width) - (block.boundingBox.x / this.windowSize.width));
      block.element.style.transitionDelay = `${distanceRatio / 2}s`;

      block.element.classList.remove('animateBackground');

      const blockCenter = [this.windowSize.width / 2, this.windowSize.height / 2];
      const angle = Math.atan2(target.x - blockCenter[0], - (target.y - blockCenter[1])) * (180 / Math.PI);
      block.element.style.transform = `rotate(${angle}deg)`;
    });
  }

  createBlocks() {
    this.lastResetSize = this.windowSize;
    let xPos = 0;
    let yPos = 0;
    let numBlocks = Math.round((this.windowSize.width / (this.radius + this.gutter)) * ((this.windowSize.height / this.radius) + 1));

    for (let i = 0; i < numBlocks; i++) {
      const block = new Block(xPos, yPos);
      block.element.style.transitionDelay = `${(250 + (i * 2))}ms`;
      block.element.style.animationDelay = `${Math.round(Math.random() * 500)}ms`

      block.element.addEventListener('transitionend', () => block.element.classList.add('animateBackground'), false);

      xPos += this.radius + this.gutter;
      if (xPos > this.windowSize.width) {
        xPos = 0;
        yPos += this.radius + this.gutter;
      }

      this.blocks.push(block);
      this.container.appendChild(block.element);
      block.init();

    }

    document.body.appendChild(this.container);
  }

  reset() {
    this.blocks.forEach((block) => {
      this.container.removeChild(block.element);
    });
    this.blocks = [];
  }

  resize() {
    this.windowSize = {
      width: window.innerWidth,
      height: window.innerHeight
    }

    if ((this.windowSize.width - this.lastResetSize.width > this.radius) ||
        (this.windowSize.height - this.lastResetSize.height > this.radius)) {
      this.reset();
      this.createBlocks();
    }
  }

  resizeThrottler() {
    if (!this.resizeTimeout_) {
      this.resizeTimeout_ = setTimeout(() => {
        this.resizeTimeout_ = null;
        this.resize();
      }, 500)
    }
  }

}

class Block {
  constructor(x, y) {
    this.element = document.createElement('div');
    this.element.className = 'block';
    this.element.style.top = `${y}px`;
    this.element.style.left = `${x}px`;
  }

  init() {
    setTimeout(() => {
      this.computeBoundingClientRect();
      this.element.classList.add('ready');
    }, 0);

    setTimeout(() => {
      this.element.classList.add('animateBackground');
    }, 1000);
  }

  computeBoundingClientRect() {
    this.boundingBox = this.element.getBoundingClientRect();
  }
}


(function() {
  const app = new App();
})();